q1=int(input("how many elements do you want to have?"))
l1=[]
l2=[]
for i in range(q1):
	s=int(input("Enter a number:"))
	l1.append(s)
	print("Your list now is =",l1)

for j in range (len(l1)):
    for k in range(len(l1)):
        if k==0 :
            l2.append([l1[j]])
        if j==0 and k==0:
            l2.extend([[]])
        if j!=k :
            if [l1[k],l1[j]] in l2:
                pass
            else:
                l2.extend([[l1[j],l1[k]]])
l2.extend([l1])

print("All possible sublists are",l2)
        
        