lst=[]
print("How many elements? ")
n=int(input())

for i in range (n):
    print("Enter element : ")
    lst.append(input())
print("The list is : ", lst)

i='Yes'
while i=='Yes' or i=='yes':
    i=input("Would you like to copy the list? ")
    c=int(input('''Which method of shallow copying would you like to use :
1. Slicing    2. List method 3.Copy function  4.Copy module'''))
    if c == 1:
        print("The list {} copied by slicing is {} ".format(lst,lst[:]))
    if c == 2:
        print("The list {} copied by list method is {} ".format(lst,list(lst)))
    if c == 3:
        print("The list {} copied by copy function is {} ".format(lst,lst.copy()))
    if c == 4:
        import copy
        print("The list {} copied by copy module is {} ".format(lst,copy.copy(lst)))
else:
    print("Thank you")
