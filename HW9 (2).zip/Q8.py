q1=int(input("how many elements do you want to compare?:"))
l1=[]
l2=[]
for i in range(q1):
	s=int(input("Enter a number:"))
	l1.append(s)
	print("Your list now is =",l1)
q2=int(input("how many elements do you want to compare?:"))
for j in range(q2):
	s=int(input("Enter a number:"))
	l2.append(s)
	print("Your list now is =",l2)

l3=[]
for k in l1:
    if k in l2:
        pass
    else:
        l3.append(k)
for l in l2:
    if l in l1:
        pass
    else:
        l3.append(l)
print("The unique elements are:",l3)

