q1=int(input("how many elements do you want to have?"))
l1=[1,2,3,4,5,6,7,8,9]
l2=[]
for i in range(q1):
	s=int(input("Enter a number"))
	l1.append(s)
	print("Your list now is =",l1)

ans=input("Do u wanna operate on a list?")

while ans=="Yes" or ans=="yes":
        print("\nHow would you like to sum the numbers in a list: \na) All the numbers \nb) At odd index\nc) At even index\nd) Multiples of 3e\ne) Halving the number at even index and doubling the number at odd index\nf)Exit")
        ans1=input("Enter an option")
# All the numbers
        if ans1=="a":
                print("The list is  =",l1)
                sum=0
                for x in l1:
                        sum+=x
                print("Sum of all numbers is:",sum)
               
# At odd index
        if ans1=="b":
                sum=0
                for j in range(1,len(l1),2):
                        sum+=l1[j]
                print("Sum of numbers at odd indexes is",sum)
#At even index
        if ans1=="c":
                sum=0
                for k in range(0,len(l1),2):
                        sum+=l1[k]
                print("Sum of numbers at even indexes is",sum)
                
#Multiples of 3
        if ans1=="d":
                sum=0
                for l in range(0,len(l1),3):
                        sum+=l1[l]
                print("Sum of numbers at indexes of multiples of 3 is",sum)

#Halving the number at even index and doubling the number at odd index
        if ans1=="e":
                sum=0
                for a in range(1,len(l1),2):
                        sum+=l1[a]*2
                for b in range(len(l1),2):
                        sum+=l1[b]/2
                print("The sum of the numbers in the list by Halving the number at even index and doubling the number at odd index is",sum)
        
        
        if ans1=="f":
                print("Thank you, maybe another time")
        break