Priority_Tasks=["Study","Extracurricular","Movies","Sleeping"]
Priority_Tasks[0:0]=["Exercise","Sports"]
print(Priority_Tasks) 
Priority_Tasks[-1:-1]=["TV","Mobile"]
print(Priority_Tasks)
x=int(len(Priority_Tasks)/2)
Priority_Tasks[x:x]=["Socializing"] 
print(Priority_Tasks)
