#footballers
q1=int(input("How many players do you want:?"))
l1=[]
l2=[]
l3=[]
l4=[]
for i in range(q1):
    name=input("Enter player's name:")
    club=input("Enter player's club:")
    goals=int(input("Enter player's goals:"))
    l1.extend([[name,club,goals]])
    print("your list is now:",l1)
for j in range(len(l1)):
    l3.append(l1[j][1])
for j in range(len(l1)):
    if  l3[j]==l1[j][1]:
        print("Players playing for",l3[j], "are",l1[j][0])
    

mx=l1[0][2]
mn=l1[0][2]
for j in range(len(l1)):
    if l1[j][2]>mx:
        mx=l1[j][2]
    if l1[j][2]<mn:
        mn=l1[j][2]
print("Highest goals is",mx)
print("Lowest goals is",mn,)


        
    


    


    
