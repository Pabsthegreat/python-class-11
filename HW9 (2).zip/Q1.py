a = [1,5,7]
b = [2, 4, 10, 11,20]
len_a= len (a)
len_b = len(b)

#initialize the index for both the lists i, j
i, j = 0,0
merge_1st=[]

# merge based on the smallest value in each list while 
(i < len_a and j < len_b)
if a[i] <= b[j]: 
    merge_1st.append (a[i])
    i+= 1
else:
    merge_1st.append(b[j])
    j += 1
merge_1st += a[i:] + b[j:]
print(merge_1st)