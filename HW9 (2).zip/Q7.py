l1=[]
for i in range (3):
    fname=input("Enter first name")
    lname=input("Enter last name")
    l1.extend([[fname,lname]])
print("What do u want to find?:\na)Find all first names which start with a string the user inputs\nb)Find the Name of the person who is lexographically the first person\nc)Find the Name of the person who is lexographically the last")
q1=input("Enter option")
if q1=="a":
    ans=input("Find names starting with string:")
    for j in range(3):
        if l1[j][0][0:len(ans)]==ans:
            print("Names starting with the given string is:\n",l1[j])
        print()
if q1=="c":
    last=[]
    for j in range(3):
        if l1[j]>last:
            last=l1[j]
    print("Name of person who is lexicographically the last is:",last)
if q1=="b":
    first=l1[0]
    for j in range(3):
        if l1[j]<first:
            first=l1[j]
    print("Name of person who is lexicographically the first is:",first)
