l1=["abcdz", 'xyzef', 'abafz',"1221z"]
l2=[]
for i in l1:
    if i[0]=="a" and i[-1]=="z":
        l2.extend([i[1:len(i)-1]])
print("Decoded message is",l2)