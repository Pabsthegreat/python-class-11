r=int(input("Enter number of rows:"))
column=int(input("Enter number of columns:"))
l1=[]
l2=[]
for n in range (r*column):
    q=int(input("Enter a number:"))
    l1.append(q)
for i in range(1,len(l1)+1):
    if i%r==0:
        z=l1[i-r:i]
        l2.extend([z])
print(l2)

for x in range(len(l2)):
    for y in range(column):
        print(l2[x][y],end=" ")
    print()


print("To add 2 matrices, the number of rows and colums must be equal")
r=int(input("Enter number of rows of 2nd matrix:"))
column=int(input("Enter number of columns of 2nd matrix:"))
l3=[]
l4=[]
#creating 2nd matrix
for n in range (r*column):
    q=int(input("Enter a number:"))
    l3.append(q)
for i in range(1,len(l3)+1):
    if i%r==0:
        z=l3[i-r:i]
        l4.extend([z])
print(l4)
for x in len(l4):
    for y in range(column):
        print(l4[x][y])
    print()

#addition
l5=[]
for i in  range (len(l2)):
    for j in range (column):
        x=(l2[i][j])+(l4[i][j])
        l5.append(x)
l6=[]
for i in range(1,len(l3)+1):
    if i%r==0:
        z=l5[i-r:i]
        l6.extend([z])
print("sum  = ",l6)

#subtraction
l7,l8=[],[]
for i in  range (len(l2)):
    for j in range (column):
        x=(l2[i][j])-(l4[i][j])
        l7.append(x)
for i in range(1,len(l3)+1):
    if i%r==0:
        z=l7[i-r:i]
        l8.extend([z])
print("Difference=",l8)
