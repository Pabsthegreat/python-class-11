#to calulate the total marks and total percentage in exams
print("Total marks and percentage calculator")
print("Please enter all marks out of 100")
s1=float(input("Enter your marks in subject 1 :"))
s2=float(input("Enter your marks in subject 2 :"))
s3=float(input("Enter your marks in subject 3 :"))
s4=float(input("Enter your marks in subject 4 :"))
s5=float(input("Enter your marks in subject 5 :"))
x=s1+s2+s3+s4+s5
print("Your total is = ", x, " out of 500")
print("Your total percentage is +", (x / 500)*100,"%")
print("Congratulations!!")
