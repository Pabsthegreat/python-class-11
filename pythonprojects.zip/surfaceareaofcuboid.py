#to calculate surface area of a cuboid
print("surface area of a cuboid calculator")
l=float(input("Enter the value of the length of your cuboid in centimeteres:"))
s=float(input("Enter the value of the breadth of your cuboid in centimeteres:"))
h=float(input("Enter the value of the height of your cuboid in centimeteres:"))
print("The surface area of the cuboid is =", 2*(l*h+s*h+l*s) , "sq.cms" )
        
