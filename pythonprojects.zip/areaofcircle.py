#to calculate area and circumference of a circle
print(" Area and cirumference of a circle calculator")
r=float(input("Enter the value of the radius of your circle in centimetres:"))
print("The circumference of the circle is =", 2*3.14*r ,"cm")
print("The area of the circle is =", 3.14*r*r ,"sq.cms")
