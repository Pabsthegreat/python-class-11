#to calculate compound interest
print("compound interest calculator")
k=float(input("Enter the principal amount :"))
r=float(input("Enter the interest rate:"))
t=float(input("Enter time period (years ) :"))
print("n = Number of times interest compounds in a year :")
n=int(input("Enter the number of times the interest is compunded in the time period :"))
y=n*t
z=r/100*n
x=float(k*(1+z )**y) 
print("The total interest you will recieve is :" ,x, "rupees")
      
