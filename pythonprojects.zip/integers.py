#opereations on 2 integers
print("Operations on integers")
num1=int(input("Enter a integer :"))
num2=int(input("Enter another integer :"))
print("The sum of the intergers is =", num1+num2 )
print("The product of the integers is =", num1*num2 )
print("The quotient of the integers is =", num1/num2)
print("The difference of the integers is =", num1-num2)
      
