#to repeat a line n times
x=int(input("enter an integer"))
print("Good day!!\n "*x)
