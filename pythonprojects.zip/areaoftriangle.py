#to calculate  area of a triangle
print("Area of a triangle calculator")
b=float(input("Enter the value of the length of your triangle in centimeteres:"))
h=float(input("Enter the value of the breadth of your cuboid in centimeteres:"))
print("The area of the triangle is =", 0.5*(b*h) , "sq.cms" )
