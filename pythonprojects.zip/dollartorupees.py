#dollar rupoee conversion
print("Dollars to rupee convertor")
d=float(input("Enter $ amount :"))
r=float(input("Enter the $ to Rs. conversion value:"))
print(d,"$ =", d*r, " Rupees")
