di={}
n=int(input("Enter number of players : "))
for i in range(n):
    name=input("Enter player name : ")
    di=dict.fromkeys(name,0)
    score=int(input("Enter score : "))
    di[name]=score
print(di)

sum1=0
high=di[name]
lst=[]

for j in di:
    lst.append(j)
print("The players in this match are:", lst)

x=input("Enter player to be viewed: ")
print(di.get(x,'Not Found'))
for i in di:
    nam=i
    sum1+=di[i]
    if high<di[i]:
        high=di[i]
        nam=i
print("The total team score is:", sum1)
print("The highest scorer in this match : ",nam, high)
