t=()
n=int(input("Enter no. of elements in tuple : "))
for i in range(n):
    t1=()
    for j in range(i+2):
        x=int(input("Enter an element : "))
        t1+=(x,)
    t+=t1,
print(t)

sum1=0
for j in t:
    sum2=0
    for k in j:
        sum2+=k
    sum1+=sum2/len(j)
    print("Mean of nested tuple is ", sum2/len(j))
avg=sum1/n
print("Mean of all means of elements in tuples is ", avg)
