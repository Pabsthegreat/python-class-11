di={}
for i in range(1,4):
    lst=[]
    for j in range(3):
        x=int(input("Enter an element : " ))
        lst.append(x)
    print()
    di[i]=lst+'\n'
print(di, sep='\n')
