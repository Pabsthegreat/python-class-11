lst1=[]
lst2=[]
n= int(input("Enter no. of countries :"))
for i in range(n):
    coun=input("Enter country name:")
    cap=input("Enter capital: ")
    lst1.append(coun)
    lst2.append(cap)
di=dict(zip(lst1,lst2))
print("Country           -           Capital")
for j in di.keys():
    print(j,di[j], sep="           -           ")
