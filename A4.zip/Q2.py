t=()
n=int(input("Enter no. of elements in tuple"))
for i in range(n):
    t1=()
    x,y=int(input("Enter an element : ")),int(input("Enter another element : "))
    t1+=((x,y),)
    t+=t1
count=0
t1=()
for j in t:
    if j[0]%2==0 and j[1]%2==0:
        count+=1
        t1+=j
print("Number of tuples with both numbers even", count)
print("Tuple of even numbers",t1)
