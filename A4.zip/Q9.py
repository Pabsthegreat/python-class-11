st=input("Enter string to be mirrored (all lowercase) : ")
n=int(input("Enter posn from which you would like to mirror : "))
st1=''
for i in range(len(st)):
    if i<n-1:
        st1+=st[i]
    else:
        c=ord(st[i])
        var=122-c
        mirror=chr(97+var)
        st1+=mirror
print(st1)
