t=()
n=int(input("Enter no. of elements in tuple"))
for i in range(n):
    x=int(input("Enter an element : "))
    t+=x,
lst=[]
for j in t:
    if j%2==1:
        lst.append(j)
print(lst)
