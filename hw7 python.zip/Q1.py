import math
num =int(input("Enter a number"))
fact=1
print("The factorial of the number", num,"is", math.fact(num))
