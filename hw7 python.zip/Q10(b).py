n=int(input("Enter a number : "))
sum1=0
for i in range (1,n+1):
    c=(i-1)/(i)
    sum1=(sum1)+c
print("The sum of all numbers till",c,"is", sum1)
